import Utils from '../utils.js';

class ListItem extends HTMLElement {
    _shadowRoot = null;
    _styles = null;
    _notes = {
        id: null,
        title: null,
        body: null,
        createdAt: null,
    };

    constructor() {
        super();


        this._shadowRoot = this.attachShadow({ mode: 'open' });
        this._style = document.createElement('style');
    }

    _emptyContent() {
        this._shadowRoot.innerHTML = '';
    }

    set note(value) {
        this._note = value;
    }

    _updateStyle() {
        this._style.textContent = `
        :host {
        display
        }`
    }
}