import notesData from "./script/data/local/notesData.js";

document.addEventListener('DOMContentLoaded', () => {
    notesData();
})

