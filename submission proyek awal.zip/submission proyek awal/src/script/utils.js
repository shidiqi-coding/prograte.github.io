class Utils{
    static showElement(Element){
        Element.style.display ='block';
        Element.hidden = false;
    }

    /*static hideElement(Element){
        Element.style.display ='none';
        Element.hidden = true;
      }*/


      static isValidInteger(newValue){
        return Number.isNan(newValue) || Number.isFinite(newValue);
      }
}

export default Utils;