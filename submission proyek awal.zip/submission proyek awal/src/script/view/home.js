import Utils from '../utils.js';
import NotesData from '../data/local/notesData.js';


const home = () =>{
    const ElementSearchForm =
    document.querySelector('#FormSearch');
    const noteListElement = 



    const displayResult = (NotesData) =>{
        const NotesItems = NotesData.map((note)) =>{
            return`
            <div class ="list-card>
            
            </div>`
        }
    } 
   }